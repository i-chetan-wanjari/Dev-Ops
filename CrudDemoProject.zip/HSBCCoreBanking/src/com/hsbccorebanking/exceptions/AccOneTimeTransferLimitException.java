package com.hsbccorebanking.exceptions;

public class AccOneTimeTransferLimitException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5345228945370636160L;

	String message;

	public AccOneTimeTransferLimitException() {
		super();
	}

	public AccOneTimeTransferLimitException(String message) {
		super(message);
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
