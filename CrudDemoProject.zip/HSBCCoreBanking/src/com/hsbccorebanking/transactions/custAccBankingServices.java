package com.hsbccorebanking.transactions;

import com.hsbccorebanking.customeraccount.CustomerAccountDTO;
import com.hsbccorebanking.exceptions.AccBalanceLowerLimitException;
import com.hsbccorebanking.exceptions.AccExistsException;
import com.hsbccorebanking.exceptions.AccOneTimeTransferLimitException;

public interface custAccBankingServices {

	public boolean createCustomerAccount(CustomerAccountDTO customerAccountTransDTO) throws AccExistsException;

	public boolean amountWithdrawlTransaction(long accountNo, double amount) throws AccBalanceLowerLimitException;

	public boolean amountDepositTransaction(long accountNo, double amount);

	public boolean amountTransferTransaction(long fromAccount, long toAccount, double amount)
			throws AccBalanceLowerLimitException, AccOneTimeTransferLimitException;

	public void viewAllCustomers();

}
