package com.hsbccorebanking.exceptions;

public class AccExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3664678996194354680L;

	private String message;

	public AccExistsException() {
		super();
	}

	public AccExistsException(String message) {
		super(message);
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}
