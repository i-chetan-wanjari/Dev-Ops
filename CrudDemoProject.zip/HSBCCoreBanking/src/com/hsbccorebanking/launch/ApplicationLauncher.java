package com.hsbccorebanking.launch;

import java.io.InputStreamReader;
import java.util.Scanner;

import com.hsbccorebanking.customeraccount.CustomerAccountDTO;
import com.hsbccorebanking.exceptions.AccBalanceLowerLimitException;
import com.hsbccorebanking.exceptions.AccExistsException;
import com.hsbccorebanking.exceptions.AccOneTimeTransferLimitException;
import com.hsbccorebanking.transactions.custAccBankingServicesImpl;

public class ApplicationLauncher {

	static boolean flag = true;

	public static void main(String[] args) {

		System.out.println("\nWelcome To HSBC Core Banking...\n");

		Scanner scanner = new Scanner(new InputStreamReader(System.in));

		while (flag) {

			welcomeToTheBanking();

			custAccBankingServicesImpl accBankingServicesImpl = new custAccBankingServicesImpl();

			int choice = scanner.nextInt();
			switch (choice) {

			case 1:

				custAccountCreation(scanner, accBankingServicesImpl);

				break;

			case 2:

				custAccWithdrawTrans(scanner, accBankingServicesImpl);

				break;

			case 3:

				custAccDepositTrans(scanner, accBankingServicesImpl);

				break;

			case 4:

				custAccTransferTrans(scanner, accBankingServicesImpl);

				break;

			case 5:

				accBankingServicesImpl.viewAllCustomers();
				continueBankingOrHalt(scanner);
				break;

			case 6:

				promptForExit(scanner);
				break;

			default:

				System.out.println("\nInvalid Option Chosen Please Select Valid Option");
				break;
			}
		}
		System.out.println("Thank You For Banking With Us...!\n");
		System.out.println("*********************************************************************\n");
		scanner.close();
	}

	private static void welcomeToTheBanking() {
		System.out.println("\n*********************************************************************\n");
		System.out.println("Choose among the following operation to be performed\n");

		System.out.println("1. Create Customer\n");
		System.out.println("2. Withdrawl Transaction\n");
		System.out.println("3. Deposit Transaction\n");
		System.out.println("4. Transfer Money\n");
		System.out.println("5. View All Customers\n");
		System.out.println("6. Exit\n");
	}

	private static void custAccTransferTrans(Scanner scanner, custAccBankingServicesImpl accBankingServicesImpl) {
		System.out.println("***Money Transfer Wizard***\n");

		System.out.print("Source Account Number          	    : ");
		long fromAccountNo = scanner.nextLong();

		System.out.print("Destination Account Number          : ");
		long toAccountNo = scanner.nextLong();

		System.out.print("Amount To Be Transferred            : ");
		double amountT = scanner.nextDouble();

		try {
			accBankingServicesImpl.amountTransferTransaction(fromAccountNo, toAccountNo, amountT);
			continueBankingOrHalt(scanner);
		} catch (AccBalanceLowerLimitException e) {
			// TODO Auto-generated catch block
			System.out.println("Error Occured : " + e.getMessage());
		} catch (AccOneTimeTransferLimitException e) {
			// TODO Auto-generated catch block
			System.out.println("\nError Occured : " + e.getMessage());
		}
	}

	private static void custAccountCreation(Scanner scanner, custAccBankingServicesImpl accBankingServicesImpl) {
		CustomerAccountDTO customerAccountDTO = new CustomerAccountDTO();

		System.out.println("***Create Customer Wizard***");
		System.out.println("Kindly Proffer The Following Details\n");

		System.out.print("Account Number          : ");
		customerAccountDTO.setAccountNo(scanner.nextLong());

		System.out.print("Account Name            : ");
		customerAccountDTO.setCustomerName(scanner.next());

		System.out.print("Account Contact         : ");
		customerAccountDTO.setCustomerContactDetails(scanner.next());

		System.out.print("Account Address         : ");
		customerAccountDTO.setCustomerAddress(scanner.next());

		System.out.print("Account Type            : ");
		customerAccountDTO.setAccountType(scanner.next());

		System.out.print("Account Opening Balance : ");
		customerAccountDTO.setAccountBalance(scanner.nextDouble());

		try {
			accBankingServicesImpl.createCustomerAccount(customerAccountDTO);
			continueBankingOrHalt(scanner);
		} catch (AccExistsException e) {
			// TODO Auto-generated catch block
			System.out.println("Error Occured : " + e.getMessage());
		}
	}

	private static void custAccDepositTrans(Scanner scanner, custAccBankingServicesImpl accBankingServicesImpl) {
		System.out.println("***Money Deposit Wizard***\n");

		System.out.print("Account Number          : ");
		long accountNoD = scanner.nextLong();

		System.out.print("Amount To Be Deposited  : ");
		double amountD = scanner.nextDouble();

		accBankingServicesImpl.amountDepositTransaction(accountNoD, amountD);
		continueBankingOrHalt(scanner);
	}

	private static void custAccWithdrawTrans(Scanner scanner, custAccBankingServicesImpl accBankingServicesImpl) {
		System.out.println("***Money Withdrawl Wizard***\n");

		System.out.print("Account Number          : ");
		long accountNoW = scanner.nextLong();

		System.out.print("Amount To Be Withdrawn : ");
		double amountW = scanner.nextDouble();

		try {
			accBankingServicesImpl.amountWithdrawlTransaction(accountNoW, amountW);
			continueBankingOrHalt(scanner);
		} catch (AccBalanceLowerLimitException e) {
			// TODO Auto-generated catch block
			System.out.println("Error Occured : " + e.getMessage());
		}
	}

	private static void continueBankingOrHalt(Scanner scanner) {
		System.out.println("\nDo you wish to continue with Banking [Y/N] ?\n");
		if ((scanner.next()).equalsIgnoreCase("N")) {
			flag = false;
		}
	}

	private static void promptForExit(Scanner scanner) {
		System.out.println("\nAre you sure to close Banking Transactions [Y/N] ?\n");
		if ((scanner.next()).equalsIgnoreCase("Y")) {
			flag = false;
		}
	}
}
