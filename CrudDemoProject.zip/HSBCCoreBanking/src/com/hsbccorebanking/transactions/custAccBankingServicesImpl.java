package com.hsbccorebanking.transactions;

import java.util.HashMap;
import java.util.Map;

import com.hsbccorebanking.customeraccount.CustomerAccountDTO;
import com.hsbccorebanking.exceptions.AccBalanceLowerLimitException;
import com.hsbccorebanking.exceptions.AccExistsException;
import com.hsbccorebanking.exceptions.AccOneTimeTransferLimitException;

public class custAccBankingServicesImpl implements custAccBankingServices {

	public static Map<Long, CustomerAccountDTO> customerAccounts = new HashMap<Long, CustomerAccountDTO>();

	@Override
	public boolean createCustomerAccount(CustomerAccountDTO customerAccountTransDTO) throws AccExistsException {
		// TODO Auto-generated method stub
		if (customerAccounts.containsKey(customerAccountTransDTO.getAccountNo())) {
			throw new AccExistsException(
					"Account you are trying to creating already exists,Please proffer different account number");
		} else {
			customerAccounts.put(customerAccountTransDTO.getAccountNo(), customerAccountTransDTO);
			System.out.print("\nCustomer Account created successfully\n");
			return true;
		}
	}

	@Override
	public boolean amountWithdrawlTransaction(long accountNo, double amount) throws AccBalanceLowerLimitException {
		// TODO Auto-generated method stub
		if (customerAccounts.containsKey(accountNo)) {
			CustomerAccountDTO customerAccountDTO = customerAccounts.get(accountNo);
			if (customerAccountDTO.getAccountBalance() > 1000) {
				double availableAccountBalance = customerAccountDTO.getAccountBalance() - amount;
				if (availableAccountBalance > 1000) {
					customerAccountDTO.setAccountBalance(availableAccountBalance);
					System.out.println("\n\nWithdrawl Transaction Successful\n");
					System.out.println(
							"Available balance in Main Account : " + customerAccountDTO.getAccountBalance() + "\n");
					return true;
				} else {
					throw new AccBalanceLowerLimitException(
							"Amount can not be withdrawl as it violates minimum balance crieteria");
				}
			} else {
				throw new AccBalanceLowerLimitException(
						"Amount can not be withdrawl as it violates minimum balance crieteria");
			}
		}
		return false;
	}

	@Override
	public boolean amountDepositTransaction(long accountNo, double amount) {
		// TODO Auto-generated method stub
		if (customerAccounts.containsKey(accountNo)) {
			CustomerAccountDTO customerAccountDTO = customerAccounts.get(accountNo);
			double totalAccountBalance = customerAccountDTO.getAccountBalance() + amount;
			customerAccountDTO.setAccountBalance(totalAccountBalance);
			System.out.println("\n\nDeposit Transaction Successful\n");
			System.out.println("Available balance in Main Account : " + customerAccountDTO.getAccountBalance() + "\n");
			return true;
		} else {
			System.out.println("Account does not exists");
		}
		return false;
	}

	@Override
	public boolean amountTransferTransaction(long fromAccount, long toAccount, double amount)
			throws AccBalanceLowerLimitException, AccOneTimeTransferLimitException {
		// TODO Auto-generated method stub

		if (customerAccounts.containsKey(fromAccount) && customerAccounts.containsKey(toAccount)) {

			CustomerAccountDTO customerAccountFromDTO = customerAccounts.get(fromAccount);
			CustomerAccountDTO customerAccountToDTO = customerAccounts.get(toAccount);
			if (amount < 50000) {
				if (customerAccountFromDTO.getAccountBalance() > 1000) {
					double availableAccountBalanceFrom = customerAccountFromDTO.getAccountBalance() - amount;
					double availableAccountBalanceTo = customerAccountToDTO.getAccountBalance() + amount;
					if (availableAccountBalanceFrom > 1000) {
						customerAccountFromDTO.setAccountBalance(availableAccountBalanceFrom);
						customerAccountToDTO.setAccountBalance(availableAccountBalanceTo);
						System.out.println("\n\nTransfer Transaction Request Successful\n");
						System.out.println("Available balance in Source Account : "
								+ customerAccountFromDTO.getAccountBalance() + "\n");
						System.out.println("Available balance in Destination Account : "
								+ customerAccountToDTO.getAccountBalance() + "\n");
						return true;
					} else {
						throw new AccBalanceLowerLimitException(
								"Amount can not be transferred as it violates minimum balance crieteria");
					}
				} else {
					throw new AccBalanceLowerLimitException(
							"Amount can not be transferred as it violates minimum balance crieteria");
				}
			} else {
				throw new AccOneTimeTransferLimitException("Amount to be transferred exceeds the limit of 50000");
			}

		} else {
			System.out.println("\nInvalid Transaction Request Occured,\nAccounts chosen for transfer transaction does not exists\n");
		}

		return false;
	}

	@Override
	public void viewAllCustomers() {
		// TODO Auto-generated method stub
		if (customerAccounts.size() > 0) {
			System.out.println("Following is the list of available customers\n");
			for (Map.Entry<Long, CustomerAccountDTO> custAccounts : customerAccounts.entrySet()) {
				if (customerAccounts.containsKey(custAccounts.getKey())) {
					System.out.println("Customer Account No.     : " + custAccounts.getValue().getAccountNo());
					System.out.println("Customer Account Name    : " + custAccounts.getValue().getCustomerName());
					System.out.println(
							"Customer Account Contact : " + custAccounts.getValue().getCustomerContactDetails());
					System.out.println("Customer Account Address : " + custAccounts.getValue().getCustomerAddress());
					System.out.println("Customer Account Type    : " + custAccounts.getValue().getAccountType());
					System.out.println("Customer Account Balance : " + custAccounts.getValue().getAccountBalance());
				}
				System.out.println("\n************************************************************\n");
			}
		} else {
			System.out.println("\nSorry,Currently no customers are available in database\n");
		}
	}

}
