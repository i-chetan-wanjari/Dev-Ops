package com.hsbccorebanking.exceptions;

public class AccBalanceLowerLimitException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3912853088024070026L;

	private String message;

	public AccBalanceLowerLimitException() {
		super();
	}

	public AccBalanceLowerLimitException(String message) {
		super(message);
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
